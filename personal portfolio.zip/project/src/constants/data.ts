// Website configuration and content data
export const siteConfig = {
  name: "John Doe",
  title: "Full Stack Developer",
  email: "hello@johndoe.com",
  description: "Creating digital experiences that matter",
  socialLinks: {
    github: "https://github.com",
    linkedin: "https://linkedin.com",
    twitter: "https://twitter.com",
    instagram: "https://instagram.com",
  },
  navigation: [
    { name: "Home", href: "#home" },
    { name: "About", href: "#about" },
    { name: "Skills", href: "#skills" },
    { name: "Projects", href: "#projects" },
    { name: "Contact", href: "#contact" },
  ],
};

export const aboutData = {
  title: "About Me",
  description: "I'm a passionate developer focused on creating intuitive and user-friendly web applications.",
  paragraphs: [
    "With over 5 years of experience in web development, I've worked on a variety of projects from small business websites to large enterprise applications.",
    "I believe in clean code, user-centered design, and continuous learning. My goal is to build digital solutions that are not only functional but also beautiful and accessible.",
    "When I'm not coding, you can find me hiking, reading, or experimenting with new technologies.",
  ],
  image: "https://images.pexels.com/photos/2379004/pexels-photo-2379004.jpeg",
};

export const skillsData = {
  title: "My Skills",
  description: "Here are some of the technologies and tools I work with.",
  categories: [
    {
      name: "Frontend",
      skills: [
        { name: "React", level: 90 },
        { name: "TypeScript", level: 85 },
        { name: "JavaScript", level: 95 },
        { name: "HTML/CSS", level: 90 },
        { name: "Tailwind CSS", level: 85 },
      ],
    },
    {
      name: "Backend",
      skills: [
        { name: "Node.js", level: 80 },
        { name: "Express", level: 75 },
        { name: "Python", level: 70 },
        { name: "MongoDB", level: 75 },
        { name: "PostgreSQL", level: 70 },
      ],
    },
    {
      name: "Tools & Others",
      skills: [
        { name: "Git", level: 85 },
        { name: "Docker", level: 70 },
        { name: "AWS", level: 65 },
        { name: "Figma", level: 75 },
        { name: "Jest", level: 70 },
      ],
    },
  ],
};

export const projectsData = {
  title: "My Projects",
  description: "Here are some of the projects I've worked on.",
  projects: [
    {
      title: "E-commerce Platform",
      description: "A full-featured e-commerce platform with payment processing, inventory management, and an admin dashboard.",
      image: "https://images.pexels.com/photos/230544/pexels-photo-230544.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2",
      tags: ["React", "Node.js", "MongoDB", "Stripe"],
      link: "https://askglobalsearch.com",
    },
    {
      title: "Task Management App",
      description: "A collaborative task management application with real-time updates, file sharing, and team collaboration features.",
      image: "https://images.pexels.com/photos/1029757/pexels-photo-1029757.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2",
      tags: ["React", "Firebase", "Redux", "Material UI"],
      link: "https://web.link.askglobalsearch.com",
    },
    {
      title: "Portfolio Website",
      description: "A responsive portfolio website with smooth animations, dark mode, and contact form functionality.",
      image: "https://images.pexels.com/photos/196644/pexels-photo-196644.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2",
      tags: ["React", "Tailwind CSS", "Framer Motion"],
      link: "https://link.askglobalsearch.com",
    },
  ],
};

export const contactData = {
  title: "Get In Touch",
  description: "Interested in working together? Feel free to reach out to me.",
  email: "hello@johndoe.com",
  phone: "+1 (555) 123-4567",
  location: "San Francisco, CA",
};