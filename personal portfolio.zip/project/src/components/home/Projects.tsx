import React from 'react';
import { ExternalLink } from 'lucide-react';
import { Section } from '../ui/Section';
import { Card } from '../ui/Card';
import { projectsData } from '../../constants/data';

export function Projects() {
  return (
    <Section
      id="projects"
      title={projectsData.title}
      description={projectsData.description}
      className="bg-white dark:bg-gray-900"
    >
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        {projectsData.projects.map((project, index) => (
          <Card key={index} hover>
            <Card.Image src={project.image} alt={project.title} />
            <Card.Content>
              <Card.Title>{project.title}</Card.Title>
              <Card.Description>{project.description}</Card.Description>
              
              <div className="flex flex-wrap gap-2 mt-4">
                {project.tags.map((tag, tagIndex) => (
                  <span 
                    key={tagIndex}
                    className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200"
                  >
                    {tag}
                  </span>
                ))}
              </div>
            </Card.Content>
            
            <Card.Footer>
              <a 
                href={project.link} 
                target="_blank"
                rel="noopener noreferrer"
                className="text-blue-600 dark:text-blue-400 hover:text-blue-800 dark:hover:text-blue-300 inline-flex items-center font-medium transition-colors"
              >
                View Project
                <ExternalLink className="ml-1 h-4 w-4" />
              </a>
            </Card.Footer>
          </Card>
        ))}
      </div>
    </Section>
  );
}