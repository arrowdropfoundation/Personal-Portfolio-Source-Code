import React from 'react';
import { Section } from '../ui/Section';
import { skillsData } from '../../constants/data';

export function Skills() {
  return (
    <Section
      id="skills"
      title={skillsData.title}
      description={skillsData.description}
      className="bg-gray-50 dark:bg-gray-800"
    >
      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        {skillsData.categories.map((category, categoryIndex) => (
          <div 
            key={categoryIndex}
            className="bg-white dark:bg-gray-900 rounded-lg shadow-md p-6"
          >
            <h3 className="text-xl font-bold mb-6 text-center text-gray-900 dark:text-white border-b border-gray-200 dark:border-gray-700 pb-3">
              {category.name}
            </h3>
            
            <div className="space-y-6">
              {category.skills.map((skill, skillIndex) => (
                <div key={skillIndex}>
                  <div className="flex justify-between mb-2">
                    <span className="text-gray-700 dark:text-gray-300 font-medium">
                      {skill.name}
                    </span>
                    <span className="text-gray-500 dark:text-gray-400 text-sm">
                      {skill.level}%
                    </span>
                  </div>
                  <div className="w-full h-2 bg-gray-200 dark:bg-gray-700 rounded-full overflow-hidden">
                    <div 
                      className="h-full bg-gradient-to-r from-blue-600 to-teal-600 rounded-full"
                      style={{ width: `${skill.level}%` }}
                      data-aos="slide-right"
                      data-aos-duration="1000"
                      data-aos-delay={`${skillIndex * 100}`}
                    ></div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>
    </Section>
  );
}