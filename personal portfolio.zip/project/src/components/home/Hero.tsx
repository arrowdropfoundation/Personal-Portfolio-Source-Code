import React, { useEffect, useRef } from 'react';
import { ChevronDown } from 'lucide-react';
import { Button } from '../ui/Button';
import { siteConfig } from '../../constants/data';

export function Hero() {
  const typingRef = useRef<HTMLSpanElement>(null);
  
  useEffect(() => {
    if (!typingRef.current) return;
    
    const phrases = ["Full Stack Developer", "UI/UX Enthusiast", "Problem Solver"];
    let currentPhraseIndex = 0;
    let currentCharIndex = 0;
    let isDeleting = false;
    let typingSpeed = 100;
    
    const type = () => {
      const currentPhrase = phrases[currentPhraseIndex];
      
      if (isDeleting) {
        // Deleting text
        if (typingRef.current) {
          typingRef.current.textContent = currentPhrase.substring(0, currentCharIndex - 1);
          currentCharIndex--;
        }
        
        // When deleted, switch to typing
        if (currentCharIndex === 0) {
          isDeleting = false;
          currentPhraseIndex = (currentPhraseIndex + 1) % phrases.length;
          // Pause after deleting
          typingSpeed = 500;
        } else {
          // Speed up deletion
          typingSpeed = 50;
        }
      } else {
        // Typing text
        if (typingRef.current) {
          typingRef.current.textContent = currentPhrase.substring(0, currentCharIndex + 1);
          currentCharIndex++;
        }
        
        // When fully typed, switch to deleting
        if (currentCharIndex === currentPhrase.length) {
          isDeleting = true;
          // Pause before deleting
          typingSpeed = 1500;
        } else {
          // Normal typing speed
          typingSpeed = 100;
        }
      }
      
      setTimeout(type, typingSpeed);
    };
    
    // Start the typing effect
    setTimeout(type, 1000);
    
    // No need to clean up as this will run once per mount
  }, []);
  
  return (
    <section 
      id="home" 
      className="relative min-h-screen flex items-center justify-center bg-gray-50 dark:bg-gray-900"
    >
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-blue-50 to-teal-50 dark:from-gray-900 dark:to-gray-800 opacity-50"></div>
        <div className="absolute top-0 left-0 right-0 h-24 bg-gradient-to-b from-white dark:from-gray-900"></div>
        <div className="absolute bottom-0 left-0 right-0 h-24 bg-gradient-to-t from-white dark:from-gray-900"></div>
      </div>
      
      <div className="container mx-auto px-4 z-10">
        <div className="max-w-3xl mx-auto text-center">
          <h1 className="text-4xl md:text-6xl font-bold mb-6 text-gray-900 dark:text-white">
            Hello, I'm{" "}
            <span className="text-blue-600 dark:text-blue-400">
              {siteConfig.name}
            </span>
          </h1>
          
          <div className="mb-8 text-2xl md:text-3xl font-medium text-gray-700 dark:text-gray-300">
            I'm a <span ref={typingRef} className="text-teal-600 dark:text-teal-400"></span>
            <span className="animate-blink">|</span>
          </div>
          
          <p className="text-lg md:text-xl text-gray-600 dark:text-gray-400 mb-10 max-w-2xl mx-auto">
            {siteConfig.description}
          </p>
          
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
            <Button 
              variant="primary" 
              size="lg"
              onClick={() => {
                const projectsSection = document.getElementById('projects');
                if (projectsSection) {
                  projectsSection.scrollIntoView({ behavior: 'smooth' });
                }
              }}
            >
              View My Work
            </Button>
            
            <Button 
              variant="outline" 
              size="lg"
              onClick={() => {
                const contactSection = document.getElementById('contact');
                if (contactSection) {
                  contactSection.scrollIntoView({ behavior: 'smooth' });
                }
              }}
            >
              Contact Me
            </Button>
          </div>
        </div>
      </div>
      
      <div className="absolute bottom-8 left-0 right-0 flex justify-center animate-bounce">
        <button
          aria-label="Scroll down"
          onClick={() => {
            const aboutSection = document.getElementById('about');
            if (aboutSection) {
              aboutSection.scrollIntoView({ behavior: 'smooth' });
            }
          }}
          className="p-2 rounded-full bg-white dark:bg-gray-800 shadow-md text-gray-700 dark:text-gray-300 hover:text-blue-600 dark:hover:text-blue-400 transition-colors"
        >
          <ChevronDown className="h-6 w-6" />
        </button>
      </div>
    </section>
  );
}