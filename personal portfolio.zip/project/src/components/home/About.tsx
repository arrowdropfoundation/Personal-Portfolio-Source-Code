import React from 'react';
import { Section } from '../ui/Section';
import { aboutData } from '../../constants/data';

export function About() {
  return (
    <Section
      id="about"
      title={aboutData.title}
      description={aboutData.description}
      className="bg-white dark:bg-gray-900"
    >
      <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
        <div className="order-2 md:order-1">
          <div className="space-y-6">
            {aboutData.paragraphs.map((paragraph, index) => (
              <p 
                key={index} 
                className="text-gray-600 dark:text-gray-400 leading-relaxed"
              >
                {paragraph}
              </p>
            ))}
          </div>
        </div>
        
        <div className="order-1 md:order-2">
          <div className="relative">
            <div className="absolute -inset-2 bg-gradient-to-r from-blue-600 to-teal-600 rounded-lg blur opacity-20 dark:opacity-40 animate-pulse"></div>
            <div className="relative overflow-hidden rounded-lg">
              <img 
                src={aboutData.image} 
                alt="Profile" 
                className="w-full h-auto rounded-lg shadow-lg transform transition-transform duration-500 hover:scale-105"
              />
            </div>
          </div>
        </div>
      </div>
    </Section>
  );
}