import React from 'react';

interface CardProps {
  className?: string;
  children: React.ReactNode;
  hover?: boolean;
}

export function Card({ className = '', children, hover = false }: CardProps) {
  return (
    <div 
      className={`
        bg-white dark:bg-gray-800 rounded-lg shadow-md overflow-hidden
        ${hover ? 'transition-transform duration-300 hover:-translate-y-2 hover:shadow-lg' : ''}
        ${className}
      `}
    >
      {children}
    </div>
  );
}

interface CardImageProps {
  src: string;
  alt: string;
  className?: string;
}

Card.Image = function CardImage({ src, alt, className = '' }: CardImageProps) {
  return (
    <div className={`w-full h-48 md:h-64 overflow-hidden ${className}`}>
      <img 
        src={src} 
        alt={alt} 
        className="w-full h-full object-cover transition-transform duration-500 hover:scale-105"
      />
    </div>
  );
};

interface CardContentProps {
  className?: string;
  children: React.ReactNode;
}

Card.Content = function CardContent({ className = '', children }: CardContentProps) {
  return (
    <div className={`p-5 ${className}`}>
      {children}
    </div>
  );
};

interface CardTitleProps {
  className?: string;
  children: React.ReactNode;
}

Card.Title = function CardTitle({ className = '', children }: CardTitleProps) {
  return (
    <h3 className={`text-xl font-bold mb-2 ${className}`}>
      {children}
    </h3>
  );
};

interface CardDescriptionProps {
  className?: string;
  children: React.ReactNode;
}

Card.Description = function CardDescription({ className = '', children }: CardDescriptionProps) {
  return (
    <p className={`text-gray-600 dark:text-gray-400 ${className}`}>
      {children}
    </p>
  );
};

interface CardFooterProps {
  className?: string;
  children: React.ReactNode;
}

Card.Footer = function CardFooter({ className = '', children }: CardFooterProps) {
  return (
    <div className={`p-5 pt-0 flex items-center justify-between ${className}`}>
      {children}
    </div>
  );
};