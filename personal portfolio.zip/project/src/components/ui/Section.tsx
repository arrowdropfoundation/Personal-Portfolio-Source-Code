import React from 'react';

interface SectionProps {
  id?: string;
  title?: string;
  description?: string;
  className?: string;
  children: React.ReactNode;
  titleClassName?: string;
  descriptionClassName?: string;
}

export function Section({
  id,
  title,
  description,
  className = '',
  children,
  titleClassName = '',
  descriptionClassName = '',
}: SectionProps) {
  return (
    <section
      id={id}
      className={`py-16 md:py-24 ${className}`}
    >
      <div className="container mx-auto px-4">
        {(title || description) && (
          <div className="mb-12 text-center">
            {title && (
              <h2 className={`text-3xl md:text-4xl font-bold mb-4 ${titleClassName}`}>
                {title}
              </h2>
            )}
            {description && (
              <p className={`text-lg text-gray-600 dark:text-gray-400 max-w-2xl mx-auto ${descriptionClassName}`}>
                {description}
              </p>
            )}
          </div>
        )}
        {children}
      </div>
    </section>
  );
}